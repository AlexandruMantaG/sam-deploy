def lambda_handler(event, context): 
    return "I work"
